﻿using System;
using System.Windows.Input;
using TouchTracking;
using Xamarin.Forms;

namespace TouchTrackingEffectDemos
{
    public partial class HomePage : ContentPage
    {
        public HomePage()
        {
            InitializeComponent();

            BindingContext = this;          
        }


        public ICommand NavigateCommand => new Command(OnNavigation);

        private async void OnNavigation(object obj)
        {
            Type pageType = obj as Type;
            Page page = (Page)Activator.CreateInstance(pageType);
            await Navigation.PushAsync(page);
        }

        public ICommand ImageClickCommand => new Command(OnImageClick);

        private void OnImageClick(object obj)
        {
            //Do Nothing            
        }

        private void TouchEffect_TouchAction(object sender, TouchActionEventArgs args)
        {
            //It gets called successfully in Android and iOS
        }
    }
}
