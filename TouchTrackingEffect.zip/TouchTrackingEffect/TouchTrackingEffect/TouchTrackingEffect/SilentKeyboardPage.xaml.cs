﻿using System;
using Xamarin.Forms;

namespace TouchTrackingEffectDemos
{
    public partial class SilentKeyboardPage : ContentPage
    {
        public SilentKeyboardPage()
        {
            InitializeComponent();
        }

        void OnKeyStatusChanged(object sender, EventArgs args)
        {

        }
    }
}
